list_available_commands = [
    "batch",
    "broadcast",
    "bc",
    "logs",
    "log",
    "ping",
    "privacy",
    "restart",
    "r",
    "start",
    "stop",
    "users",
    "uptime",
    "set",
]

__all__ = ["list_available_commands"]
