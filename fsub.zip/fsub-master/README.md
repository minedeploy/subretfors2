<!DOCTYPE html>
<html>
<body>
  <a href="https://heroku.com/deploy?template=https://github.com/ugorwx/fsub">
    <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
  </a>
</body>
</html>
