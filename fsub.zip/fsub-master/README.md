<!DOCTYPE html>
<html>
<body>
  <a href="https://heroku.com/deploy?template=https://github.com/dot7z/fsub">
    <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
  </a>
</body>
</html>
