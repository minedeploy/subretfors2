list_available_commands = [
    "batch",
    "broadcast",
    "bc",
    "log",
    "ping",
    "privacy",
    "start",
    "stop",
    "users",
    "uptime",
]

__all__ = ["list_available_commands"]
