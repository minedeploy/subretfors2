list_available_commands = [
    "batch",
    "broadcast",
    "bc",
    "eval",
    "e",
    "logs",
    "log",
    "ping",
    "privacy",
    "restart",
    "r",
    "shell",
    "sh",
    "start",
    "stop",
    "users",
    "uptime",
]

__all__ = ["list_available_commands"]
